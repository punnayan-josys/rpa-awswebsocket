exports.handler = async (event) => {
  return { isAuthorized: true };
}; 